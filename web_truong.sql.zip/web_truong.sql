--
-- Database: `web_truong`
--

-- --------------------------------------------------------

--
-- Table structure for table `bo_mon`
--

CREATE TABLE `bo_mon` (
  `id_bo_mon` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_khong_dau` text NOT NULL,
  `mo_ta` text NOT NULL,
  `hinh_anh` varchar(45) DEFAULT NULL,
  `lien_he` varchar(45) DEFAULT NULL,
  `id_khoa` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bo_mon`
--

INSERT INTO `bo_mon` (`id_bo_mon`, `name`, `name_khong_dau`, `mo_ta`, `hinh_anh`, `lien_he`, `id_khoa`, `created_at`, `updated_at`) VALUES
(1, 'Bộ môn Các Hệ thống Thông tin', 'bo-mon-cac-he-thong-thong-tin', '<p>\r\n	Bộ m&ocirc;n Hệ thống th&ocirc;ng tin (HTTT) được th&agrave;nh lập từ năm 1995 c&ugrave;ng với thời điểm th&agrave;nh lập Khoa C&ocirc;ng nghệ th&ocirc;ng tin, Trường Đại học Khoa học tự nhi&ecirc;n, đến nay Bộ m&ocirc;n đ&atilde; ph&aacute;t triển đội ngũ c&aacute;n bộ d&agrave;y dạn kinh nghiệm trong giảng dạy cũng như nghi&ecirc;n cứu khoa học. Hiện tại Bộ m&ocirc;n c&oacute; 6 PGS, 5 tiến sĩ, 6 thạc sĩ v&agrave; nhiều sinh vi&ecirc;n giỏi ở lại l&agrave;m c&aacute;n bộ tạo nguồn. Nhiều c&aacute;n bộ trong bộ m&ocirc;n tốt nghiệp tiến sĩ tại c&aacute;c viện, trường đại học ti&ecirc;n tiến ở c&aacute;c nước Nhật, Ph&aacute;p, H&agrave;n Quốc. Cũng như nhiều gi&aacute;o sư, giảng vi&ecirc;n ở c&aacute;c trường, viện ti&ecirc;n tiến ở nước ngo&agrave;i tham gia l&agrave;m giảng vi&ecirc;n ki&ecirc;m nhiệm tại bộ m&ocirc;n.</p>\r\n', NULL, 'Địa chỉ: 305 – E3 – 144 Xuân Thuỷ – Cầu Giấy ', 1, NULL, '2016-12-03 09:08:31'),
(2, 'Bộ môn Công nghệ Phần mềm', 'bo-mon-cong-nghe-phan-mem', '<p>\r\n	Bộ m&ocirc;n CNPM đảm nhận vai tr&ograve; quan trọng trong ph&aacute;t triển c&aacute;c ng&agrave;nh v&agrave; chuy&ecirc;n ng&agrave;nh tại khoa CNTT, bao gồm cả đ&agrave;o tạo cử nh&acirc;n, thạc sĩ, v&agrave; tiến sĩ. Giảng vi&ecirc;n của bộ m&ocirc;n tham gia x&acirc;y dựng khung chương tr&igrave;nh, đề cương chi tiết, x&acirc;y dựng gi&aacute;o tr&igrave;nh, giảng dạy nhiều m&ocirc;n học cơ sở của CNTT v&agrave; c&aacute;c m&ocirc;n chuy&ecirc;n ng&agrave;nh theo định hướng CNPM.</p>\r\n', NULL, 'Địa chỉ: 305 – E3 – 144 Xuân Thuỷ – Cầu Giấy', 1, NULL, '2016-12-09 16:18:16'),
(3, 'Bộ môn Khoa học Máy tính', 'bo-mon-khoa-hoc-may-tinh', '<p>\r\n	Th&agrave;nh lập từ năm 1995, đến nay Bộ m&ocirc;n Khoa học m&aacute;y t&iacute;nh đ&atilde; ph&aacute;t triển đội ngũ c&aacute;n bộ d&agrave;y dạn kinh nghiệm trong giảng dạy cũng như nghi&ecirc;n cứu khoa học v&agrave; ph&aacute;t triển hệ thống. Bộ m&ocirc;n c&oacute; 1 gi&aacute;o sư, 2 PGS, 8 tiến sĩ, 3 thạc sĩ v&agrave; nhiều sinh vi&ecirc;n giỏi ở lại l&agrave;m c&aacute;n bộ tạo nguồn. Nhiều c&aacute;n bộ trong bộ m&ocirc;n tốt nghiệp tiến sĩ tại c&aacute;c viện, trường đại học ti&ecirc;n tiến ở c&aacute;c nước Mỹ, Nhật, Anh, &Uacute;c, Đức. Nhiều gi&aacute;o sư, giảng vi&ecirc;n ở c&aacute;c trường, viện ti&ecirc;n tiến ở nước ngo&agrave;i tham gia l&agrave;m giảng vi&ecirc;n ki&ecirc;m nhiệm tại bộ m&ocirc;n: GS Hồ T&uacute; Bảo, PGS. Huỳnh Văn Nam, PGS. Nguyễn L&ecirc; Minh, GS. Th&aacute;i Tr&agrave; My đại học Florida, PGS. Nguyễn Xu&acirc;n Long đại học Michigan, Mỹ. C&aacute;c c&aacute;n bộ, giảng vi&ecirc;n của Bộ m&ocirc;n được đ&agrave;o tạo cơ bản v&agrave; chuy&ecirc;n s&acirc;u về nhiều lĩnh vực trong Khoa học m&aacute;y t&iacute;nh. Bộ m&ocirc;n c&oacute; chiến lược tập trung v&agrave;o c&aacute;c hướng nghi&ecirc;n cứu chủ đạo l&agrave; &ldquo;Học m&aacute;y thống k&ecirc; v&agrave; ứng dụng&rdquo; v&agrave; &ldquo;Xử l&yacute; ng&ocirc;n ngữ tự nhi&ecirc;n&rdquo;. Bộ m&ocirc;n định hướng ph&aacute;t triển tiếp c&aacute;c hướng trong tương lai về xử l&yacute; tiếng n&oacute;i, xử l&yacute; ảnh.</p>\r\n', NULL, 'Địa chỉ: 305 – E3 – 144 Xuân Thuỷ – Cầu Giấy', 1, NULL, '2016-12-09 16:18:22'),
(4, 'Bộ môn Mạng và Truyền thông Máy tính', 'bo-mon-mang-va-truyen-thong-may-tinh', '<p>\r\n	Bộ m&ocirc;n Mạng v&agrave; Truyền th&ocirc;ng m&aacute;y t&iacute;nh được th&agrave;nh lập v&agrave;o năm 2004 với nhiệm vụ: Giảng dạy c&aacute;c m&ocirc;n học thuộc ng&agrave;nh v&agrave; chuy&ecirc;n ng&agrave;nh Mạng v&agrave; Truyền th&ocirc;ng m&aacute;y t&iacute;nh ở bậc đại học v&agrave; sau đại học Hướng dẫn sinh vi&ecirc;n l&agrave;m kh&oacute;a luận tốt nghiệp, luận văn cao học v&agrave; luận văn tiến sỹ Thực hiện c&aacute;c nghi&ecirc;n cứu ti&ecirc;n tiến trong lĩnh vực Mạng v&agrave; Truyền th&ocirc;ng m&aacute;y t&iacute;nh Đội ngũ giảng vi&ecirc;n của bộ m&ocirc;n hiện đang c&oacute; 6 tiến sỹ, 4 thạc sỹ trong đ&oacute; c&oacute; nhiều giảng vi&ecirc;n được đ&agrave;o tạo tại c&aacute;c viện, trường đại học ti&ecirc;n tiến tr&ecirc;n thế giới. C&aacute;c c&aacute;n bộ của bộ m&ocirc;n đ&atilde; thực hiện nhiều đề t&agrave;i, c&ocirc;ng tr&igrave;nh nghi&ecirc;n cứu khoa học ti&ecirc;n tiến trong lĩnh vực mạng v&agrave; truyền th&ocirc;ng như c&aacute;c đề t&agrave;i về mạng ngang h&agrave;ng, t&iacute;nh to&aacute;n ph&acirc;n t&aacute;n, mạng kh&ocirc;ng d&acirc;y, an ninh mạng, &hellip;. B&ecirc;n cạnh đ&oacute;, bộ m&ocirc;n cũng đ&atilde; c&oacute; một số hợp t&aacute;c nghi&ecirc;n cứu với nhiều ph&ograve;ng th&iacute; nghiệm của c&aacute;c trường đại học tr&ecirc;n thế giới như Đại học British Columbia (Canada), Đại học Paris Sud 11 (Ph&aacute;p), Đại học North Carolina tại Charlotte, (Mỹ), Đại học Massachusetts Boston (Mỹ), Viện khoa học v&agrave; c&ocirc;ng nghệ ti&ecirc;n tiến Nhật Bản (JAIST), &hellip;. Bộ m&ocirc;n Mạng v&agrave; Truyền th&ocirc;ng m&aacute;y t&iacute;nh đang phấn đấu để trở th&agrave;nh địa chỉ giảng dạy v&agrave; nghi&ecirc;n cứu h&agrave;ng đầu tại Việt Nam trong lĩnh vực Mạng v&agrave; Truyền th&ocirc;ng m&aacute;y t&iacute;nh. Với mục ti&ecirc;u g&oacute;p phần th&uacute;c đẩy sự ph&aacute;t triển của khoa học v&agrave; c&ocirc;ng nghệ trong lĩnh vực mạng v&agrave; truyền th&ocirc;ng m&aacute;y t&iacute;nh tại Việt Nam cũng như tr&ecirc;n thế giới, c&aacute;c c&aacute;n bộ giảng vi&ecirc;n của bộ m&ocirc;n Mạng v&agrave; truyền th&ocirc;ng m&aacute;y t&iacute;nh đ&atilde; thực hiện nhiều đề t&agrave;i, c&ocirc;ng tr&igrave;nh nghi&ecirc;n cứu khoa học theo c&aacute;c định hướng ch&iacute;nh bao gồm C&aacute;c c&ocirc;ng nghệ mạng ti&ecirc;n tiến C&aacute;c mạng kh&ocirc;ng d&acirc;y di động C&aacute;c ứng dụng mạng thế hệ mới</p>\r\n', NULL, 'Địa chỉ: 305 – E3 – 144 Xuân Thuỷ – Cầu Giấy', 2, NULL, '2016-12-09 16:18:28'),
(5, 'Bộ môn Khoa học và Kỹ thuật tính toán', 'bo-mon-khoa-hoc-va-ky-thuat-tinh-toan', '<p>\r\n	Bộ m&ocirc;n Khoa học &amp; Kỹ thuật t&iacute;nh to&aacute;n được th&agrave;nh lập th&aacute;ng 12/2013 với tiền th&acirc;n l&agrave; Bộ m&ocirc;n C&aacute;c Phương ph&aacute;p to&aacute;n trong C&ocirc;ng nghệ (được th&agrave;nh lập năm 2003). Bộ m&ocirc;n &ldquo;Khoa học v&agrave; Kỹ Thuật T&iacute;nh To&aacute;n với chức năng nhiệm vụ phụ tr&aacute;ch một số m&ocirc;n cơ bản li&ecirc;n quan đến khoa học v&agrave; kỹ thuật như: C&aacute;c m&ocirc;n to&aacute;n chung của trường, To&aacute;n rời rạc, Xử l&yacute; số t&iacute;n hiệu, X&aacute;c suất &ndash; Thống k&ecirc;, Tối ưu h&oacute;a v&agrave; Phương ph&aacute;p t&iacute;nh. Ngo&agrave;i ra, Bộ m&ocirc;n c&ograve;n phụ tr&aacute;ch ph&aacute;t triển phong tr&agrave;o Olympic như Olympic to&aacute;n to&agrave;n quốc, Olympic tin học to&agrave;n quốc. C&aacute;c c&aacute;n bộ, giảng vi&ecirc;n của Bộ m&ocirc;n được đ&agrave;o tạo cơ bản v&agrave; chuy&ecirc;n s&acirc;u về nhiều lĩnh vực li&ecirc;n quan đến c&aacute;c phương ph&aacute;p to&aacute;n trong c&ocirc;ng nghệ, khoa học v&agrave; kỹ thuật t&iacute;nh to&aacute;n, khai ph&aacute; dữ liệu, tin sinh học, mật m&atilde; v&agrave; an to&agrave;n th&ocirc;ng tin, c&aacute;c hệ thống thương mại trực tuyến, c&aacute;c phương ph&aacute;p v&agrave; hệ thống t&iacute;nh to&aacute;n lớn. Bộ m&ocirc;n c&oacute; chiến lược tập trung v&agrave;o c&aacute;c hướng nghi&ecirc;n cứu chủ đạo l&agrave; &ldquo;Tin Sinh học (Sinh học T&iacute;nh to&aacute;n) &ndash; Ph&acirc;n t&iacute;ch Hệ gene&rdquo;, đặc biệt ứng dụng của n&oacute; li&ecirc;n quan đến sức khỏe con người, &ldquo;Bảo mật &ndash; An to&agrave;n th&ocirc;ng tin&rdquo; v&agrave; &ldquo;C&aacute;c hệ thống thương mại điện tử v&agrave; hệ thống t&iacute;nh to&aacute;n lớn&rdquo;.</p>\r\n', NULL, 'Địa chỉ: 305 – E3 – 144 Xuân Thuỷ – Cầu Giấy', 1, NULL, '2016-12-09 16:18:33');

-- --------------------------------------------------------

--
-- Table structure for table `de_tai`
--

CREATE TABLE `de_tai` (
  `id_de_tai` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_khong_dau` varchar(100) NOT NULL,
  `tom_tat` varchar(1000) NOT NULL,
  `noi_dung` text NOT NULL,
  `id_huong_nghien_cuu` int(11) NOT NULL,
  `id_sv` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `giang_vien`
--

CREATE TABLE `giang_vien` (
  `id_giang_vien` int(11) NOT NULL,
  `id_khoa` int(11) NOT NULL,
  `id_bo_mon` int(11) DEFAULT NULL,
  `id_ptn` int(11) DEFAULT NULL,
  `id_linh_vuc` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name_khong_dau` varchar(45) NOT NULL,
  `hinh_anh` varchar(50) DEFAULT NULL,
  `level` smallint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `giang_vien`
--

INSERT INTO `giang_vien` (`id_giang_vien`, `id_khoa`, `id_bo_mon`, `id_ptn`, `id_linh_vuc`, `id_user`, `name`, `email`, `name_khong_dau`, `hinh_anh`, `level`, `created_at`, `updated_at`) VALUES
(43589, 1, 1, 1, NULL, 43589, 'Phạm Huy Mạnh 1435', 'uetmail.web@gmail.com', 'pham-huy-manh-1435', NULL, 2, '2016-12-09 07:55:06', '2016-12-09 16:58:24'),
(123456, 2, 1, 1, NULL, 123456, 'Bùi Ngọc Hải', 'huymanhtmhp@gmail.com', 'bui-ngoc-hai', NULL, 2, '2016-12-06 06:12:43', '2016-12-09 15:53:55'),
(123457, 1, 2, 2, NULL, 123457, 'Bùi Ngọc Thăng', 'huymanhtmhp123@gmail.com', 'bui-ngoc-thang', NULL, 2, '2016-12-06 06:12:43', '2016-12-06 06:12:43'),
(123458, 1, 3, 3, NULL, 123458, 'Bùi Quang Hưng', 'huymanhtmhp@gmail.com', 'bui-quang-hung', NULL, 2, '2016-12-06 06:12:43', '2016-12-06 06:12:43'),
(123459, 1, NULL, NULL, NULL, 123459, 'Dư Phương Hạnh', 'huymanhtmhp123@gmail.com', 'du-phuong-hanh', NULL, 2, '2016-12-06 06:12:43', '2016-12-06 06:12:43'),
(123460, 1, NULL, NULL, NULL, 123460, 'Dương Lê Minh', 'huymanhtmhp@gmail.com', 'duong-le-minh', NULL, 2, '2016-12-06 06:12:43', '2016-12-06 06:12:43'),
(123461, 1, NULL, NULL, NULL, 123461, 'Hoàng Minh Đường', 'huymanhtmhp123@gmail.com', 'hoang-minh-duong', NULL, 2, '2016-12-06 06:12:43', '2016-12-06 06:12:43'),
(123462, 1, NULL, NULL, NULL, 123462, 'Hoàng Thị Ngọc Trang', 'huymanhtmhp@gmail.com', 'hoang-thi-ngoc-trang', NULL, 2, '2016-12-09 07:49:33', '2016-12-09 07:49:33'),
(123463, 1, NULL, NULL, NULL, 123463, 'Hoàng Thị Điệp', 'huymanhtmhp123@gmail.com', 'hoang-thi-diep', NULL, 2, '2016-12-09 07:56:02', '2016-12-09 07:56:02'),
(123464, 1, NULL, NULL, NULL, 123464, 'Hoàng Xuân Huấn', 'huymanhtmhp@gmail.com', 'hoang-xuan-huan', NULL, 2, '2016-12-09 07:56:02', '2016-12-09 07:56:02'),
(123465, 1, NULL, NULL, NULL, 123465, 'Hoàng Xuân Tùng', 'huymanhtmhp123@gmail.com', 'hoang-xuan-tung', NULL, 2, '2016-12-09 07:56:03', '2016-12-09 07:56:03');

-- --------------------------------------------------------

--
-- Table structure for table `huong_nghien_cuu`
--

CREATE TABLE `huong_nghien_cuu` (
  `id_huong_nghien_cuu` int(11) NOT NULL,
  `id_giang_vien` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `name_khong_dau` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `huong_nghien_cuu`
--

INSERT INTO `huong_nghien_cuu` (`id_huong_nghien_cuu`, `id_giang_vien`, `name`, `name_khong_dau`, `created_at`, `updated_at`) VALUES
(9, 123456, 'Tối ưu hóa hệ thống nhúng', 'toi-uu-hoa-he-thong-nhung', '2016-12-09 07:32:43', '2016-12-09 07:32:43'),
(10, 123456, 'Công nghệ phần mềm nhúng', 'cong-nghe-phan-mem-nhung', '2016-12-09 07:32:57', '2016-12-09 07:32:57'),
(12, 123457, 'Học máy', 'hoc-may', '2016-12-09 07:40:04', '2016-12-09 07:40:04'),
(13, 123457, 'Tin sinh học', 'tin-sinh-hoc', '2016-12-09 07:40:21', '2016-12-09 07:40:21'),
(14, 123458, 'Hạ tầng dữ liệu không gian', 'ha-tang-du-lieu-khong-gian', '2016-12-09 07:41:31', '2016-12-09 07:41:31'),
(15, 123458, 'Hệ thống thông tin địa lý', 'he-thong-thong-tin-dia-ly', '2016-12-09 07:41:44', '2016-12-09 07:41:44');

-- --------------------------------------------------------

--
-- Table structure for table `khoa`
--

CREATE TABLE `khoa` (
  `id_khoa` int(11) NOT NULL,
  `name` text NOT NULL,
  `name_khong_dau` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `khoa`
--

INSERT INTO `khoa` (`id_khoa`, `name`, `name_khong_dau`, `updated_at`, `created_at`) VALUES
(1, 'Khoa Công nghệ thông tin', 'khoa-cong-nghe-thong-tin', NULL, NULL),
(2, 'Khoa Điện tử Viễn thông', 'khoa-dien-tu-vien-thong', NULL, NULL),
(3, 'Khoa Vật lý Kỹ thuật & Công nghệ Nanô', 'khoa-vat-ky-ki-thuat-cong-nghe-nano', NULL, NULL),
(4, 'Khoa Cơ học Kỹ thuật & Tự động hóa', 'khoa-co-hoc-ky-thuat-tu-dong-hoa', NULL, NULL),
(5, 'Khoa Cơ điện tử', 'khoa-co-dien-tu', '2016-11-29 18:07:56', '2016-11-29 18:07:56'),
(6, 'Khoa Công nghệ vi tính', 'khoa-cong-nghe-vi-tinh', '2016-11-30 04:26:51', '2016-11-30 04:26:51');

-- --------------------------------------------------------

--
-- Table structure for table `khoa_hoc`
--

CREATE TABLE `khoa_hoc` (
  `id_khoa_hoc` int(50) NOT NULL,
  `name` varchar(45) NOT NULL,
  `ki_hieu` varchar(45) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `khoa_hoc`
--

INSERT INTO `khoa_hoc` (`id_khoa_hoc`, `name`, `ki_hieu`, `created_at`, `updated_at`) VALUES
(1, 'Khóa 2014', 'K59', '2016-12-06 17:00:00', '2016-11-30 17:00:00'),
(2, 'Khóa 2015', 'K60', '2016-11-30 17:00:00', '2016-12-21 17:00:00'),
(3, 'Khóa 2016', 'K61', '2016-11-30 17:00:00', '2016-12-01 17:00:00'),
(4, 'Khóa 2017', 'K62', '2016-12-06 03:27:31', '2016-12-06 03:27:31');

-- --------------------------------------------------------

--
-- Table structure for table `linh_vuc`
--

CREATE TABLE `linh_vuc` (
  `id_linh_vuc` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `name_khong_dau` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `linh_vuc`
--

INSERT INTO `linh_vuc` (`id_linh_vuc`, `name`, `name_khong_dau`) VALUES
(1, 'Phân tích dữ liệu', 'phan-tich-du-lieu'),
(2, 'Quản trị hệ thống ', 'quan-tri-he-thong'),
(3, 'Lập trình viên', 'lap-trinh-vien'),
(4, 'Kỹ sư phần mềm', 'ky-su-phan-mem'),
(5, 'Phân tích hệ thống ', 'phan-tich-he-thong'),
(6, 'Chuyên viên hỗ trợ kỹ thuật', 'chuyen-vien-ho-tro-ky-thuat'),
(7, 'Thiết kế web/ dịch vụ Internet ', 'thiet-ke-web-dich-vu-internet');

-- --------------------------------------------------------

--
-- Table structure for table `nganh_hoc`
--

CREATE TABLE `nganh_hoc` (
  `id_nganh_hoc` int(50) NOT NULL,
  `name` varchar(45) NOT NULL,
  `name_khong_dau` varchar(45) NOT NULL,
  `ki_hieu` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nganh_hoc`
--

INSERT INTO `nganh_hoc` (`id_nganh_hoc`, `name`, `name_khong_dau`, `ki_hieu`, `created_at`, `updated_at`) VALUES
(1, 'Công nghệ thông tin', 'cong-nghe-thong-tin', 'CNTT', '2016-11-30 17:00:00', '2016-11-30 17:00:00'),
(2, 'Điện tử', 'dien-tu', 'DT', '2016-11-30 17:00:00', '2016-11-30 17:00:00'),
(4, 'Công nghệ sinh học', 'cong-nghe-sinh-hoc', 'CNSH', '2016-12-06 03:56:07', '2016-12-06 03:56:07');

-- --------------------------------------------------------

--
-- Table structure for table `phong_thi_nghiem`
--

CREATE TABLE `phong_thi_nghiem` (
  `id_phong_thi_nghiem` int(11) NOT NULL,
  `id_khoa` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_khong_dau` varchar(100) NOT NULL,
  `mo_ta` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `phong_thi_nghiem`
--

INSERT INTO `phong_thi_nghiem` (`id_phong_thi_nghiem`, `id_khoa`, `name`, `name_khong_dau`, `mo_ta`, `created_at`, `updated_at`) VALUES
(1, 1, 'Phòng Thí nghiệm An toàn thông tin', 'phong-thi-nghiem-an-toan-thong-tin', '<p>\r\n	Ph&ograve;ng th&iacute; nghiệm An to&agrave;n th&ocirc;ng tin được th&agrave;nh lập th&aacute;ng 12 năm 2013 c&oacute; nhiệm vụ đ&agrave;o tạo v&agrave; nghi&ecirc;n cứu về c&aacute;c lĩnh vực an to&agrave;n th&ocirc;ng tin v&agrave; an ninh mạng. Một số đề t&agrave;i nghi&ecirc;n cứu của ph&ograve;ng th&iacute; nghiệm: Ph&aacute;t triển thử nghiệm hệ thống cảnh b&aacute;o ch&aacute;y sử dụng mạng cảm biến kh&ocirc;ng d&acirc;y. Trường Đại học C&ocirc;ng nghệ, ĐHQGHN, 2013-2014. N&acirc;ng cao hiệu năng của một số giao thức định tuyến trong c&aacute;c mạng kh&ocirc;ng d&acirc;y. Trường Đại học C&ocirc;ng nghệ, Đại học Quốc gia H&agrave; Nội, 2011-2012. Nghi&ecirc;n cứu x&acirc;y dựng Hệ thống cung cấp v&agrave; quản l&yacute; chứng chỉ số thuộc Hạ tầng cơ sở mật m&atilde; kh&oacute;a c&ocirc;ng khai (PKI), nhằm bảo đảm an to&agrave;n c&aacute;c giao dịch tr&ecirc;n mạng m&aacute;y t&iacute;nh, phục vụ c&ocirc;ng t&aacute;c quản l&yacute; Nh&agrave; nước tại TP H&agrave; Nội. Th&agrave;nh phố H&agrave; Nội, 2007-2008. Nghi&ecirc;n cứu ứng dụng c&ocirc;ng nghệ t&aacute;c tử t&igrave;m kiếm, truy nhập v&agrave; truyền tải th&ocirc;ng tin tr&ecirc;n mạng Internet. Trường Đại học C&ocirc;ng nghệ, ĐHQGHN, 2005-2006. Hạ tầng cơ sở mật m&atilde; kh&oacute;a c&ocirc;ng khai (PKI), nhằm bảo đảm an to&agrave;n c&aacute;c giao dịch tr&ecirc;n mạng m&aacute;y t&iacute;nh, phục vụ c&ocirc;ng t&aacute;c quản l&yacute; Nh&agrave; nước tại TP H&agrave; Nội. Th&agrave;nh phố H&agrave; Nội, 2005-2006. Nghi&ecirc;n cứu khả năng, hiệu quả của một số thuật to&aacute;n trong an to&agrave;n truyền tin. Bộ Khoa học v&agrave; C&ocirc;ng nghệ, 2004-2005.</p>\r\n', '2016-11-28 20:07:04', '2016-12-09 16:19:10'),
(2, 1, 'Phòng Thí nghiệm Công nghệ Tri thức', 'phong-thi-nghiem-cong-nghe-tri-thuc', 'hòng Thí nghiệm Công nghệ Tri thức (Knowledge Technology Laboratory – KTLab), Khoa Công nghệ Thông tin được thành lập theo quyết định số 1070/QĐ-TCHC ngày 15/11/2010 của Hiệu trưởng Trường Đại học Công nghệ, Đại học Quốc gia Hà Nội. Tiền thân của KTLab là nhóm nghiên cứu Khai phá dữ liệu và ứng dụng (1998 – 2006) và Phòng Thí nghiệm vệ tinh “Công nghệ Tri thức và An toàn dữ liệu” (SIS-KTLab, 2006 – 2010). Bên cạnh nhiệm vụ đạo tạo đại học và sau đại học, KTLab tập trung thúc đẩy việc tổ chức và triển khai các dự án nghiên cứu về khoa học dữ liệu (data science) và công nghệ tri thức (knowledge technology) cũng như việc hợp tác với doanh nghiệp, các đơn vị trong nước và quốc tế.\r\n\r\nKTLab hiện nay có một phó giáo sư, 1 tiến sĩ, 2 thạc sĩ có nhiều kinh nghiệm trong giảng dạy đào tạo và triển khai các dự án nghiên cứu về khai phá dữ liệu (data mining), học máy (machine learning), trí tuệ doanh nghiệp (business intelligence). Ngoài ra, với lịch sử phát triển từ năm 1998, KTLab có một lực lượng đông đảo các cán bộ cộng tác viên đang công tác trong và ngoài nước như Giáo sư Nguyễn Hùng Sơn, Giáo sư Nguyễn Anh Linh (Ba Lan), Tiến sĩ Đoàn Sơn (Hoa Kỳ), TS. Nguyễn Cẩm Tú (Trung Quốc).', '2016-11-29 20:08:13', NULL),
(3, 1, 'Phòng Thí nghiệm Hệ thống Nhúng', 'phong-thi-nghiem-he-thong-nhung', 'Ngày 11 tháng 10 năm 2005 Đại học Quốc gia Hà Nội (ĐHQGHN) đã phê duyệt dự án “Đầu tư chiều sâu trang thiết bị, nâng cao năng lực nghiên cứu khoa học và triển khai ứng dụng công nghệ” cho Phòng thí nghiệm Các hệ tích hợp thông minh – SIS (Smart Integrated Systems). Phòng thí nghiệm (PTN) SIS thuộc trường Đại học Công nghệ đã được thành lập ngày 11 tháng 8 năm 2006 (theo Quyết định số 406/QĐ-TCCB&CTSV), bao gồm các PTN vệ tinh: 1/ Central Lab: VLSI/ASIC Systems Design LAB-0; 2/ SP Lab: Signal Processing Laboratory; 3/ INS Lab: Intelligent Networks and Systems Laboratory; 4/ KTIS Lab: Knowledge Technology and Information Security Laboratory và 5/ Laboratory of Embedded Systems.\r\n\r\nPhòng thí nghiệm Hệ thống nhúng (PTN HTN) được thành lập ngày 15 tháng 11 năm 2010, với chức năng sau:\r\n\r\nTổ chức nghiên cứu và triển khai ứng dụng trong lĩnh vực hệ thống nhúng;\r\nThực hiện nhiệm vụ đào tạo sau đại học và đào tạo đại học; Tổ chức triển khai giải pháp tích hợp đào tạo và nghiên cứu khoa học;\r\nKhai thác, sử dụng trang thiết bị được đầu tư từ Dự án “Đầu tư chiều sâu trang thiết bị, nâng cao năng lực nghiên cứu khoa học và triển khai ứng dụng cho phòng thí nghiệm các hệ tích hợp thông minh” phục vụ các hướng nghiên cứu về hệ thống nhúng.\r\nCác nhiệm vụ cụ thể:\r\n\r\nNghiên cứu các vấn đề lý thuyết, công nghệ và quy trình sản xuất các hệ thống nhúng. Các kết quả nghiên cứu này cần được sử dụng cho các môn học có liên quan trong trường ĐHCN.\r\nThử nghiệm chế tạo một số hệ thống nhúng từ đơn giản đến phức tạp. Nhiệm vụ này cần gắn với việc làm Khóa luận tốt nghiệp của sinh viên, hoặc Luận văn Cao học, hoặc Luận án Tiến sĩ.\r\nĐưa vào áp dụng một số hệ thống nhúng, trước hết là tại trường ĐHCN để đánh giá hiệu quả của việc áp dụng. Những hệ thống có nhiều khả năng áp dụng rộng rãi sẽ được đầu tư nghiên cứu để sản xuất và đưa ra thị trường.\r\nTìm kiếm và thiết lập các mối quan hệ hợp tác trong nước và quốc tế trong việc nghiên cứu và triển khai ứng dụng (R&D), cũng như đào tạo nhân lực làm việc trong lĩnh vực hệ thống nhúng.', '2016-11-29 22:10:22', NULL),
(4, 1, 'Phòng Thí nghiệm Tương tác Người – Máy', 'phong-thi-nghiem-tuong-tac-nguoi-may', 'Được thành lập từ năm 2008, phòng thí nghiệm Tương tác Người máy đã có đội ngũ cán bộ dày dặn kinh nghiệm trong công tác nghiên cứu khoa học cũng như giảng dạy. PTN có 2 phó giáo sư, 4 tiến sỹ, 2 thạc sỹ. Nhiều cán bộ tốt nghiệp tiến sỹ từ các cơ sở đào tạo tiến tiến ở các nước phát triển như: Úc, Hà Lan, Ý, Hàn Quốc.\r\n\r\nPhòng thí nghiệm Tương tác người-máy đảm nhận nhiệm vụ: Tổ chức nghiên cứu và triển khai ứng dụng về tương tác người-máy, xử lý ngôn ngữ tự nhiên, xử lý ảnh, đồ hoạ máy tính và bảo mật ảnh,… Tổ chức thực hiện điểm các giải pháp tích hợp đào tạo và nghiên cứu khoa học, góp phần thực hiện chủ trương đào tạo phân luồng theo định hướng học thuật, đào tạo chất lượng cao và đào tạo trình độ quốc tế. Thực hiện nhiệm vụ đào tạo đại học, sau đại học. Các cán bộ nghiên cứu của phòng thí nghiệm được đào tạo cơ bản và chuyên sâu về nhiễu lĩnh vực trong Khoa học máy tính trong đó có:\r\n\r\nXử lý ngôn ngữ tự nhiên\r\nĐồ họa máy tính\r\nXử lý ảnh\r\nXử lý video\r\nThị giác máy\r\nXử lý ảnh viễn thám\r\nPhân tích dữ liệu không thời gian', '2016-11-28 22:09:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sinh_vien`
--

CREATE TABLE `sinh_vien` (
  `id_sinh_vien` int(11) NOT NULL,
  `id_khoa` int(11) NOT NULL,
  `id_khoa_hoc` int(50) NOT NULL,
  `id_nganh_hoc` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `name_khong_dau` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(45) NOT NULL,
  `level` smallint(4) NOT NULL,
  `quyen_de_tai` smallint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sinh_vien`
--

INSERT INTO `sinh_vien` (`id_sinh_vien`, `id_khoa`, `id_khoa_hoc`, `id_nganh_hoc`, `id_user`, `name`, `name_khong_dau`, `email`, `level`, `quyen_de_tai`, `created_at`, `updated_at`) VALUES
(14020631, 1, 1, 1, 14020631, 'Phạm Huy Mạnh', 'pham-huy-manh', 'huymanhtmhp@gmail.com', 1, 1, '2016-12-10 09:47:10', '2016-12-10 09:51:15'),
(14020632, 1, 1, 1, 14020632, 'Trần Thu Thảo', 'tran-thu-thao', 'uetweb-mail@gmail.com', 1, 1, '2016-12-10 09:47:10', '2016-12-10 09:51:15'),
(14020633, 1, 1, 1, 14020633, 'Phó Đại Nam Phong', 'pho-dai-nam-phong', 'a@gmail.com', 1, 1, '2016-12-10 09:47:10', '2016-12-10 09:51:15'),
(14020634, 1, 1, 1, 14020634, 'Phạm Đức Trọng', 'pham-duc-trong', 'b@gmail.com', 1, 0, '2016-12-10 09:47:10', '2016-12-10 10:01:09'),
(14020635, 1, 2, 1, 14020635, 'Trần Văn Mạnh', 'tran-van-manh', 'c@gmail.com', 1, 1, '2016-12-10 09:47:10', '2016-12-10 10:10:14'),
(14020636, 1, 2, 1, 14020636, 'Đặng Tuấn Vũ', 'dang-tuan-vu', 'd@gmail.com', 1, 0, '2016-12-10 09:47:10', '2016-12-10 09:47:10'),
(14020637, 1, 2, 1, 14020637, 'Hà Văn Sửu', 'ha-van-suu', 'e@gmail.com', 1, 0, '2016-12-10 09:47:10', '2016-12-10 09:47:10'),
(14020638, 1, 3, 1, 14020638, 'Cầm Trung Thành', 'cam-trung-thanh', 'f@gmail.com', 1, 0, '2016-12-10 09:47:10', '2016-12-10 09:47:10'),
(14020639, 1, 3, 1, 14020639, 'Phạm Văn Trung', 'pham-van-trung', 'g@gmail.com', 1, 0, '2016-12-10 09:47:10', '2016-12-10 09:47:10'),
(14020640, 1, 3, 1, 14020640, 'Nguyễn Thị Hương Sen', 'nguyen-thi-huong-sen', 'h@gmail.com', 1, 0, '2016-12-10 09:47:11', '2016-12-10 09:47:11');

-- --------------------------------------------------------

--
-- Table structure for table `vpk`
--

CREATE TABLE `vpk` (
  `id_vpk` int(11) NOT NULL,
  `name` text NOT NULL,
  `id_khoa` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name_khong_dau` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vpk`
--

INSERT INTO `vpk` (`id_vpk`, `name`, `id_khoa`, `created_at`, `updated_at`, `name_khong_dau`) VALUES
(1234, 'Phòng công tác sinh viên', 1, '2016-12-03 12:11:06', '2016-12-04 06:04:00', 'phong-cong-tac-sinh-vien'),
(1245, 'Phòng đạo tạo', 2, '2016-12-03 12:11:39', '2016-12-04 06:03:53', 'phong-dao-tao');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bo_mon`
--
ALTER TABLE `bo_mon`
  ADD PRIMARY KEY (`id_bo_mon`),
  ADD KEY `bomon_to_khoa_idx` (`id_khoa`),
  ADD KEY `id_khoa` (`id_khoa`);

--
-- Indexes for table `de_tai`
--
ALTER TABLE `de_tai`
  ADD PRIMARY KEY (`id_de_tai`),
  ADD KEY `detai_to_hnc_idx` (`id_huong_nghien_cuu`),
  ADD KEY `detai_to_sv_idx` (`id_sv`);

--
-- Indexes for table `giang_vien`
--
ALTER TABLE `giang_vien`
  ADD PRIMARY KEY (`id_giang_vien`),
  ADD KEY `giangvien_to_bomon_idx` (`id_bo_mon`),
  ADD KEY `giangvien_to_ptn_idx` (`id_ptn`),
  ADD KEY `giangvien_to_linhvuc_idx` (`id_linh_vuc`),
  ADD KEY `id_khoa` (`id_khoa`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `huong_nghien_cuu`
--
ALTER TABLE `huong_nghien_cuu`
  ADD PRIMARY KEY (`id_huong_nghien_cuu`),
  ADD KEY `hnc_to_gv_idx` (`id_giang_vien`);

--
-- Indexes for table `khoa`
--
ALTER TABLE `khoa`
  ADD PRIMARY KEY (`id_khoa`);

--
-- Indexes for table `khoa_hoc`
--
ALTER TABLE `khoa_hoc`
  ADD PRIMARY KEY (`id_khoa_hoc`);

--
-- Indexes for table `linh_vuc`
--
ALTER TABLE `linh_vuc`
  ADD PRIMARY KEY (`id_linh_vuc`);

--
-- Indexes for table `nganh_hoc`
--
ALTER TABLE `nganh_hoc`
  ADD PRIMARY KEY (`id_nganh_hoc`);

--
-- Indexes for table `phong_thi_nghiem`
--
ALTER TABLE `phong_thi_nghiem`
  ADD PRIMARY KEY (`id_phong_thi_nghiem`),
  ADD KEY `ptn_to_khoa_idx` (`id_khoa`);

--
-- Indexes for table `sinh_vien`
--
ALTER TABLE `sinh_vien`
  ADD PRIMARY KEY (`id_sinh_vien`),
  ADD KEY `sv_to_khoa_idx` (`id_khoa`),
  ADD KEY `sv_to_khoahoc_idx` (`id_khoa_hoc`),
  ADD KEY `sv_to_nganhhoc_idx` (`id_nganh_hoc`),
  ADD KEY `id_khoa_hoc` (`id_khoa_hoc`),
  ADD KEY `id_nganh_hoc` (`id_nganh_hoc`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `vpk`
--
ALTER TABLE `vpk`
  ADD PRIMARY KEY (`id_vpk`),
  ADD KEY `vpk_to_khoa_idx` (`id_khoa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `de_tai`
--
ALTER TABLE `de_tai`
  MODIFY `id_de_tai` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `huong_nghien_cuu`
--
ALTER TABLE `huong_nghien_cuu`
  MODIFY `id_huong_nghien_cuu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `khoa_hoc`
--
ALTER TABLE `khoa_hoc`
  MODIFY `id_khoa_hoc` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `linh_vuc`
--
ALTER TABLE `linh_vuc`
  MODIFY `id_linh_vuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `nganh_hoc`
--
ALTER TABLE `nganh_hoc`
  MODIFY `id_nganh_hoc` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bo_mon`
--
ALTER TABLE `bo_mon`
  ADD CONSTRAINT `id_to_id` FOREIGN KEY (`id_khoa`) REFERENCES `khoa` (`id_khoa`) ON UPDATE CASCADE;

--
-- Constraints for table `de_tai`
--
ALTER TABLE `de_tai`
  ADD CONSTRAINT `detai_to_hnc` FOREIGN KEY (`id_huong_nghien_cuu`) REFERENCES `huong_nghien_cuu` (`id_huong_nghien_cuu`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `detai_to_sv` FOREIGN KEY (`id_sv`) REFERENCES `sinh_vien` (`id_sinh_vien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `giang_vien`
--
ALTER TABLE `giang_vien`
  ADD CONSTRAINT `giangvien_to_bomon` FOREIGN KEY (`id_bo_mon`) REFERENCES `bo_mon` (`id_bo_mon`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `giangvien_to_linhvuc` FOREIGN KEY (`id_linh_vuc`) REFERENCES `linh_vuc` (`id_linh_vuc`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `giangvien_to_ptn` FOREIGN KEY (`id_ptn`) REFERENCES `phong_thi_nghiem` (`id_phong_thi_nghiem`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `gv_to_khoa` FOREIGN KEY (`id_khoa`) REFERENCES `khoa` (`id_khoa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gv_to_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `huong_nghien_cuu`
--
ALTER TABLE `huong_nghien_cuu`
  ADD CONSTRAINT `hnc_to_gv` FOREIGN KEY (`id_giang_vien`) REFERENCES `giang_vien` (`id_giang_vien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `phong_thi_nghiem`
--
ALTER TABLE `phong_thi_nghiem`
  ADD CONSTRAINT `ptn_to_khoa` FOREIGN KEY (`id_khoa`) REFERENCES `khoa` (`id_khoa`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `sinh_vien`
--
ALTER TABLE `sinh_vien`
  ADD CONSTRAINT `sv_to_khoa` FOREIGN KEY (`id_khoa`) REFERENCES `khoa` (`id_khoa`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `sv_to_khoahoc` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `khoa_hoc` (`id_khoa_hoc`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `sv_to_nganhhoc` FOREIGN KEY (`id_nganh_hoc`) REFERENCES `nganh_hoc` (`id_nganh_hoc`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `sv_to_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vpk`
--
ALTER TABLE `vpk`
  ADD CONSTRAINT `vpk_to_khoa` FOREIGN KEY (`id_khoa`) REFERENCES `khoa` (`id_khoa`) ON DELETE NO ACTION ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
